###########################################################################
###########################################################################
###                                                                     ###
###                    Título: Rodando modelos de regressão             ###
###                                                                     ###
###########################################################################
###########################################################################

# Autor: Alexandre Silva Nogueira
# Data: 26/09/2022

#   1. Objetivo do script:

#   Este script roda os modelos de regressão
#   logística com os bancos sim 2020 e 2021
#   sobrepostos.

#   2. Carregando pacotes:
library("pacman")
p_load(tidyverse, data.table, here, fs,
       lubridate, sf, geobr, googledrive,
       openxlsx, abjutils, sidrar,
       deflateBR, brazilmaps, ggrepel, broom)

options(scipen=999)

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    1. Abrindo bancos                 |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\data")

sim <- readRDS("sim_completo_2020e2021.RDS")
pea_sim <- readRDS("pea_sim_2020e2021_preparado_para_regressao.RDS")

# Análise exploratória:
pea_sim_geral <- pea_sim %>%
  filter(ANO == 2021) %>%
  filter(COVID == 1) %>%
  filter(!is.na(SEXO) & RACACOR != "Indigena")

prop.table(table(pea_sim_geral$SEXO, useNA = "always"))
prop.table(table(pea_sim_geral$RACACOR, useNA = "always"))
prop.table(table(pea_sim_geral$RACACOR, pea_sim_geral$SEXO, useNA = "always"))

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    Preparando o banco p/ o modelo    |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# 1. Retirando indígenas e missings em sexo do banco:
pea_sim_ajust <- pea_sim %>%
  #filter(ANO == 2020) %>%
  # filtrar de abril a setembro de 2020 e 2021. Filtrar também de abril a julho.
  filter(DATAOBITO>= "2021-04-01" & DATAOBITO < "2021-10-01") %>%
  filter(!is.na(SEXO) & RACACOR != "Indigena") %>%
  transmute(id_cbo_4,
            cbo_4,
            id_cbo_1,
            cbo_1 = str_to_sentence(cbo_1, locale = "br"),
            id_cbo_4_agreg,
            cbo_4_agreg,
            grupo,
            hierarquia,
            COVID = as.factor(COVID),
            IDADE = as.numeric(IDADE),
            SEXO = as.factor(SEXO),
            RACACOR = as.factor(RACACOR),
            DATAOBITO)

# 2. Olhando excluídos:
### 2239 observações num universo de 676.483 (0.033%)
pea_sim %>%
  filter(is.na(SEXO) | RACACOR == "Indigena") %>%
  count()

2239/676483

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|   Criando funções e aplicando        |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# 1 - Estabelecendo funções aplicadas aos modelos

# 1.1 - Função para modelo com todo o banco:
foo <- function(bar) {
  glm(formula = COVID ~ IDADE + interaction(SEXO, RACACOR) + grupo,
      data = bar,
      family = "binomial")
}

# 1.2 - Função para modelo por ocupação:
foos <- function(bar) {
  glm(formula = COVID ~ IDADE + interaction(SEXO, RACACOR),
      data = bar,
      family = "binomial")
  }

# 2 - Aplicando modelo a todo o banco:
model <- foo(pea_sim_ajust)
summary(model)

# 2.1 - Criando dataframe com resumo do modelo geral:
model_tidy <- tidy(model) %>%
  mutate(OR = exp(estimate),
         IC_inf = exp(estimate - 1.96 * std.error),
         IC_sup = exp(estimate + 1.96 * std.error))

view(model_tidy)

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|   Modelagem por perfil ocupacional   |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# 1 - Aninhando os dados e aplicando múltiplas regressões:

# 1.2 - Grande grupo ocupacional (grupo)
pea_sim_nested_grupo <- pea_sim_ajust %>%
  group_by(hierarquia, grupo) %>%
  ungroup() %>%
  nest(-c(hierarquia, grupo)) %>%
  mutate(models = map(data, ~ foos(.)),
         tidied = map(models, tidy)) %>%
  unnest(tidied)

# 1.2 - Família ocupacional (CBO 4 dígitos)
pea_sim_nested_cbo_4_agreg <- pea_sim_ajust %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg, hierarquia, grupo) %>%
  filter(n_distinct(SEXO) >= 2 & n_distinct(RACACOR) >= 2) %>%
  ungroup() %>%
  nest(-c(id_cbo_4_agreg, cbo_4_agreg, hierarquia, grupo)) %>%
  mutate(models = map(data, ~ foos(.)),
         tidied = map(models, tidy)) %>%
  unnest(tidied)

#        |#|
#       \###/
#        \#/
#         *

# 2 - Criando conjuntos de dados com razões de chance e IC's

# 2.1 - Grande grupo ocupacional (CBO 1 dígito)
models_tidy_grupo <- pea_sim_nested_grupo %>%
  select(-c(data, models)) %>%
  mutate(OR = exp(estimate),
         IC_inf = exp(estimate - 1.96 * std.error),
         IC_sup = exp(estimate + 1.96 * std.error)) ### IC de 5%

# 2.2 - Família ocupacional (CBO 4 dígitos)
models_tidy_cbo_4_agreg <- pea_sim_nested_cbo_4_agreg %>%
  select(-c(data, models)) %>%
  mutate(OR = exp(estimate),
         IC_inf = exp(estimate - 1.96 * std.error),
         IC_sup = exp(estimate + 1.96 * std.error)) ### IC de 5%

#        |#|
#       \###/
#        \#/
#         *

# 3 - Filtrando modelos por significância estatística

# 3.1
models_tidy_grupo_signif <- models_tidy_grupo %>%
  filter(!term %in% c("(Intercept)", "IDADE")) %>%
  # mutate(p.adjusted = p.adjust(p.value, method = "bonferroni")) %>%
  # mutate(p.adjusted = if_else(p.value >= .5, 1, p.value/4)) %>%
  # filter(p.adjusted < .1) %>%
  filter(p.value < .05)

# 3.2
models_tidy_cbo_4_agreg_signif <- models_tidy_cbo_4_agreg %>%
  filter(!term %in% c("(Intercept)", "IDADE")) %>%
  mutate(p.adjusted = p.adjust(p.value)) %>%
  # filter(p.adjusted < .2) %>%
  filter(p.value < .05)

# (4) Checando resultados preliminares

## Checando aninhamento dos dados
glimpse(pea_sim_2020_nested_cbo_1)
glimpse(pea_sim_2020_nested_cbo_4)
glimpse(pea_sim_2020_nested_cbo_1_agreg)
glimpse(pea_sim_2020_nested_cbo_4_agreg)

## Checando dados excluídos
### ERRO: contrasts can be applied only to factors with 2 or more levels
### Ocupação deve ter pelo menos 2 valores distintos nas variáveis categóricas
pea_sim_2020_ajust %>%
  group_by(id_cbo_4, cbo_4) %>%
  filter(n_distinct(SEXO) < 2 & n_distinct(RACACOR) < 2) %>%
  group_nest() %>%
  count() ## 32 famílias de ocupação excluídas

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|      Visualizando resultados cbo_4   |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# (6) Visualizando resultados

## Número de classificações ocupacionais com diferenças significativas
n_distinct(models_tidy_grupo_signif$hierarquia) # 19 de 20
n_distinct(models_tidy_cbo_4_agreg_signif$id_cbo_4_agreg) # 52 de 77 ocupações

## Gráficos com razões de chance

### Novo grande grupo ocupacional proposto pelo especialista
plt_cbo_4_agreg <- models_tidy_cbo_4_agreg_signif %>%
  mutate(yaxis = length(grupo):1,
         term = str_remove(term, "\\s*\\([^\\)]+\\)"),
         term = str_remove(term, "interaction"),
         term = toupper(gsub("\\.", " ", term)),
         term = str_to_sentence(term, locale = "br"),
         categoria = paste(grupo, term, sep = " - "))

### Razões de chance por grupo ocupacional com diferença demográfica significativa
plt_cbo_4_agreg %>%
  ggplot(aes(x = OR, y = yaxis)) +
  geom_vline(aes(xintercept = 1), size = .25, linetype = "dashed") +
  geom_errorbarh(aes(xmin = IC_inf, xmax = IC_sup), size = .5,
                 height = .2, color = "gray50") +
  geom_point(aes(colour = grupo), size = 3.5) +
  theme_bw() +
  theme(panel.grid.minor = element_blank()) +
  scale_y_continuous(breaks = plt_cbo_4_agreg$yaxis,
                     labels = plt_cbo_4_agreg$categoria) +
  # scale_x_continuous(breaks = seq(0,7,1)) +
  ylab("") +
  xlab("Razão de chances") +
  ggtitle("Razões de chances e Intervalos de confiança \nGrupos Ocupacionais (elaboração própria)") +
  theme(legend.position = "none")

## Nova família de ocupação agregada proposta pelo especialista
plt_cbo_4 <- models_tidy_cbo_4_agreg_signif %>%
  mutate(term = case_when(term == "interaction(SEXO, RACACOR)Homem.Preto ou pardo" ~ "Homem preto ou pardo",
                          term == "interaction(SEXO, RACACOR)Mulher.Preto ou pardo" ~ "Mulher preta ou parda",
                          term == "interaction(SEXO, RACACOR)Mulher.Branco ou Amarelo" ~ "Mulher branca ou amarela",
                          TRUE ~ term),
         cbo_4 = cbo_4_agreg,
         grupo = as.factor(paste0(grupo, " - Grupo ", hierarquia)),
         grupo = fct_reorder(grupo, hierarquia))

### A - Homem negro vs Homem branco:
plt_cbo_4 %>%
  filter(term == "Homem preto ou pardo") %>%
  # top_n(10, OR) %>%
  filter(!id_cbo_4_agreg %in% c(3522, 5191, 351, 223, 262, 721, 631, 5161, 3432)) %>%
  ggplot(aes(x = fct_reorder(cbo_4, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                                   size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - homens pretos e pardos comparados a homens brancos",
       # subtitle = " Agregação de famílias de ocupação CBO (4 dígitos)",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(cbo_4,
                                              ": homens negros têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance")
                                              )),
                           alpha = .7,
                           size = 4,
                           direction = "y",
                           # colour = "white",
                           # nudge_y = c(-3, 3),
                           # nudge_y = 3.5,
                           segment.size = 0,
                           max.overlaps = 15) +
  coord_flip() +
  # scale_y_continuous(limits = c(-.6, 6)) +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.8,.5), # .2 .5
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

### B - Mulheres negras vs homens brancos
plt_cbo_4 %>%
  filter(term == "Mulher preta ou parda") %>%
  ggplot(aes(x = fct_reorder(cbo_4, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                  size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - mulheres negras comparadas a homens brancos",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(cbo_4,
                                              ": mulheres negras têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance"))),
                           # fontface = "bold",
                           alpha = .7,
                           size = 4,
                           direction = "y",
                           # colour = "white",
                           # nudge_y = c(-3, 3),
                           # nudge_y = 3.5,
                           segment.size = 0,
                           max.overlaps = 15) +
  coord_flip() +
  # scale_y_continuous(limits = c(-.6, 2.6)) +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.8,.4),
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

### C - Mulheres brancas vs homens brancos
plt_cbo_4 %>%
  filter(term == "Mulher branca ou amarela") %>%
  filter(IC_sup < 4) %>%
  top_n(10, OR) %>%
  ggplot(aes(x = fct_reorder(cbo_4, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                  size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - mulheres brancas comparadas a homens brancos",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(cbo_4,
                                              ": mulheres brancas têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance"))),
                           # fontface = "bold",
                           alpha = .7,
                           size = 4,
                           direction = "y",
                           # colour = "white",
                           # nudge_y = c(-3, 3),
                           # nudge_y = 3.5,
                           segment.size = 0,
                           max.overlaps = 0) +
  coord_flip() +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.8,.4),
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|      Visualizando resultados:        |##|
# |##|        grupos                        |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

## Nova família de ocupação agregada proposta pelo especialista
  plt_grupo <- models_tidy_grupo_signif %>%
  mutate(grupo = ifelse(is.na(hierarquia), "Outros", grupo),
         hierarquia = ifelse(is.na(hierarquia), 22, hierarquia),
         term = case_when(term == "interaction(SEXO, RACACOR)Homem.Preto ou pardo" ~ "Homem preto ou pardo",
                          term == "interaction(SEXO, RACACOR)Mulher.Preto ou pardo" ~ "Mulher preta ou parda",
                          term == "interaction(SEXO, RACACOR)Mulher.Branco ou Amarelo" ~ "Mulher branca ou amarela",
                          TRUE ~ term),
         grupo = grupo,
         grupo = as.factor(paste0(grupo, " - Grupo ", hierarquia)),
         grupo = fct_reorder(grupo, hierarquia))

### A - Homem negro vs Homem branco:
plt_grupo %>%
  filter(term == "Homem preto ou pardo") %>%
  # top_n(10, OR) %>%
  #filter(!id_cbo_4_agreg %in% c(3522, 5191, 351, 223, 262, 721, 631, 5161, 3432)) %>%
  ggplot(aes(x = fct_reorder(grupo, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                  size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - homens pretos e pardos comparados a homens brancos (Abril a Setembro 2021)",
       # subtitle = " Agregação de famílias de ocupação CBO (4 dígitos)",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(grupo,
                                              ": homens negros têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance")
  )),
  alpha = .7,
  size = 4,
  direction = "y",
  # colour = "white",
  # nudge_y = c(-3, 3),
  # nudge_y = 3.5,
  segment.size = 0,
  max.overlaps = 15) +
  coord_flip() +
  # scale_y_continuous(limits = c(-.6, 6)) +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.8,.5), # .2 .5
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

### B - Mulheres negras vs homens brancos:
plt_grupo %>%
  filter(term == "Mulher preta ou parda") %>%
  ggplot(aes(x = fct_reorder(grupo, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                  size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - mulheres negras comparadas a homens brancos (Abril a Setembro 2021)",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(grupo,
                                              ": mulheres negras têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance"))),
                           # fontface = "bold",
                           alpha = .7,
                           size = 4,
                           direction = "y",
                           # colour = "white",
                           # nudge_y = c(-3, 3),
                           # nudge_y = 3.5,
                           segment.size = 0,
                           max.overlaps = 15) +
  coord_flip() +
  # scale_y_continuous(limits = c(-.6, 2.6)) +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.84,.4),
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

### C - Mulheres brancas vs homens brancos:
plt_grupo %>%
  filter(term == "Mulher branca ou amarela") %>%
  filter(IC_sup < 4) %>%
  top_n(10, OR) %>%
  ggplot(aes(x = fct_reorder(grupo, OR), y = OR)) +
  geom_pointrange(aes(colour = grupo, ymin = IC_inf, ymax = IC_sup), alpha = .5,
                  size=1) +
  geom_hline(yintercept = 1, colour = "black", linetype = 2, alpha = .2) +
  labs(title = "Estimativa de chances de óbito por covid - mulheres brancas comparadas a homens brancos (Abril a Setembro 2021)",
       x = "",
       y = "") +
  ggrepel::geom_text_repel(aes(label = paste0(grupo,
                                              ": mulheres brancas têm ",
                                              scales::percent(round(OR - 1, 2)),
                                              if_else(OR < 1, " de chance", " mais chance"))),
                           # fontface = "bold",
                           alpha = .7,
                           size = 4,
                           direction = "y",
                           # colour = "white",
                           # nudge_y = c(-3, 3),
                           # nudge_y = 3.5,
                           segment.size = 0,
                           max.overlaps = 15) +
  coord_flip() +
  scale_y_continuous(limits = c(-.5, 6),
                     breaks = seq(from = -.0, to = 6, by = 1),
                     labels = function(x) paste0(-(1-x)*100, "%")) +
  theme_minimal() +
  theme(legend.title = element_blank(),
        legend.position = c(.8,.4),
        title = element_text(face = "bold"),
        # axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.ticks.x = element_blank())

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|      Exportando resultados           |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

## Exportando resultados para arquivo no formato planilha
setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\outputs")

write.xlsx(models_tidy_cbo_4_agreg_signif, "modelo 2020_cbo_4_agreg_somente com significancia.xlsx")
write.xlsx(models_tidy_grupo_signif, "modelo abril a setembro 2021_grupo ocupacional_somente com significancia.xlsx")

#                                      ~~~~~ Fim ~~~~~
