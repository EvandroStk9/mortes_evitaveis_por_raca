###########################################################################
###########################################################################
###                                                                     ###
###                    Título: Análise exploratória do SIM              ###
###                                                                     ###
###########################################################################
###########################################################################

# Autor: Alexandre Silva Nogueira
# Data: 19/10/2022

#   1. Objetivo do script:

#   Este script faz uma análise exploratória
#   dos dados do SIM 2020 e 2021.

#   2. Carregando pacotes:
library("pacman")
p_load(tidyverse, data.table, here, fs,
       lubridate, sf, geobr, googledrive,
       openxlsx, abjutils, sidrar, ggpmisc,
       deflateBR, brazilmaps, ggrepel, broom,
       scales)

options(scipen=999)

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    1. Abrindo bancos                 |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\data")

sim <- readRDS("sim_completo_2020e2021.RDS")
pea_sim <- readRDS("pea_sim_2020e2021_preparado_para_regressao.RDS")

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    2. Análise exploratória           |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

#
sim %>%
  #filter(ANO == 2020) %>%
  filter(COVID == 1) %>%
  summarise(n = n())

pea_sim %>%
  #filter(ANO == 2020) %>%
  filter(COVID == 1) %>%
  summarise(n = n())

676485/3428763

# 1. Resumindo missing em pea_sim:
stats_pea_sim <- pea_sim %>%
  filter(COVID == 1) %>%
  summarize(across(everything(), ~ list(n = sum(!is.na(.)),
                                        n_distinct = n_distinct(.),
                                        Missing = sum(is.na(.)),
                                        Missing_prop = round(mean(is.na(.)), 2),
                                        Mean = round(mean(., na.rm = TRUE), 2))),
  Stat = c("N", "N_distinct", "Missing", "Missing_prop", "Mean")) %>%
  select(Stat, everything())

# 2. óbitos por covid na PEA + PIA:
sim %>%
  filter(COVID == 1) %>%
  group_by(SEXO, RACACOR) %>%
  summarize(obitos = n_distinct(id_obito)) %>%
  ungroup() %>%
  ggplot(aes(obitos, fct_reorder(RACACOR, desc(obitos)), fill = SEXO)) +
  geom_col(colour = "black") +
  labs(title = "Óbitos por covid - PEA + PIA",
       x = "",
       y = "",
       caption = "Fonte: SIM/DATASUS, 2020",) +
  theme(plot.title = element_text(size=10, face = "bold"),
        # legend.position = "bottom",
        legend.title = element_blank())

# 3. óbitos por covid na PEA somente:
pea_sim %>%
  filter(COVID == 1) %>%
  group_by(SEXO, RACACOR) %>%
  summarize(obitos = n_distinct(id_obito)) %>%
  ungroup() %>%
  ggplot(aes(obitos, fct_reorder(RACACOR, desc(obitos)), fill = SEXO)) +
  geom_col(colour = "black") +
  labs(title = "Óbitos por covid - PEA",
       x = "",
       y = "",
       caption = "Fonte: SIM/DATASUS, 2020",) +
  theme(plot.title = element_text(size=10, face = "bold"),
        # legend.position = "bottom",
        legend.title = element_blank())

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|3. Síntese COVID e PEA por cbo_4_agreg|##|
# |##|  sem ocupações com menos de 50 obitos|##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# 1. Obitos por cbo_4_agreg:
pea_cbo_4_agreg <- pea_sim %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg) %>%
  summarize(obitos_cbo_4 = n_distinct(id_obito)) %>%
  arrange(desc(obitos_cbo_4))

pea_cbo_4_agreg_2020 <- pea_sim %>%
  filter(ANO == 2020) %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg) %>%
  summarize(obitos_cbo_4 = n_distinct(id_obito)) %>%
  arrange(desc(obitos_cbo_4))

pea_cbo_4_agreg_2021 <- pea_sim %>%
  filter(ANO == 2021) %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg) %>%
  summarize(obitos_cbo_4 = n_distinct(id_obito)) %>%
  arrange(desc(obitos_cbo_4))


# 2. Obitos por grupo:
pea_grupo <- pea_sim %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_grupo = n_distinct(id_obito)) %>%
  arrange(desc(obitos_grupo))

pea_grupo_2020 <- pea_sim %>%
  filter(ANO == 2020) %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_grupo = n_distinct(id_obito)) %>%
  arrange(desc(obitos_grupo))

pea_grupo_2021 <- pea_sim %>%
  filter(ANO == 2021) %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_grupo = n_distinct(id_obito)) %>%
  arrange(desc(obitos_grupo))

#        |#|
#       \###/
#        \#/
#         *

# 3. Total de morte por covid:
sim %>%
  filter(COVID == 1) %>%
  #filter(ANO == 2021) %>%
  summarise(n = n())

# 4. Síntese com a proporção de obitos covid por ocup_4_agreg:
sint_covid_pea_cbo_4_agreg <- pea_sim %>%
  filter(COVID == 1) %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg, grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 630065) %>%
  ungroup() %>%
  left_join(pea_cbo_4_agreg, by = c("id_cbo_4_agreg", "cbo_4_agreg")) %>%
  mutate(obitos_covid_cada_100_cbo_4_agreg = (obitos_covid / obitos_cbo_4) * 100) %>%
  filter(obitos_cbo_4 > 50)

# 4.1 Síntese ano 2020:
sint_covid_pea_cbo_4_agreg_2020 <- pea_sim %>%
  filter(ANO == 2020) %>%
  filter(COVID == 1) %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg, grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 209720) %>%
  ungroup() %>%
  left_join(pea_cbo_4_agreg_2020, by = c("id_cbo_4_agreg", "cbo_4_agreg")) %>%
  mutate(obitos_covid_cada_100_cbo_4_agreg_2020 = (obitos_covid / obitos_cbo_4) * 100) %>%
  filter(obitos_cbo_4 > 50)

# 4.2 Síntese ano 2021:
sint_covid_pea_cbo_4_agreg_2021 <- pea_sim %>%
  filter(ANO == 2021) %>%
  filter(COVID == 1) %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg, grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 420345) %>%
  ungroup() %>%
  left_join(pea_cbo_4_agreg_2021, by = c("id_cbo_4_agreg", "cbo_4_agreg")) %>%
  mutate(obitos_covid_cada_100_cbo_4_agreg_2021 = (obitos_covid / obitos_cbo_4) * 100) %>%
  filter(obitos_cbo_4 > 50)

# 4.3 - Calculando aumento percentual:
sint_covid_pea_cbo_4_agreg_comparacao <- sint_covid_pea_cbo_4_agreg_2020 %>%
  bind_cols(sint_covid_pea_cbo_4_agreg_2021) %>%
  mutate(aumento_percentual = (obitos_covid_cada_100_cbo_4_agreg_2021 - obitos_covid_cada_100_cbo_4_agreg_2020) / obitos_covid_cada_100_cbo_4_agreg_2020)


#        |#|
#       \###/
#        \#/
#         *

# 5 - Síntese com a proporção de obitos covid por grupo ajustado:
sint_covid_pea_grupo <- pea_sim %>%
  filter(COVID == 1) %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 630065) %>%
  ungroup() %>%
  left_join(pea_grupo, by = c("grupo", "hierarquia")) %>%
  mutate(obitos_covid_cada_100_grupo = (obitos_covid / obitos_grupo) * 100) %>%
  filter(obitos_grupo > 50)

# 5.1 - Síntese para 2020
sint_covid_pea_grupo_2020 <- pea_sim %>%
  filter(ANO == 2020) %>%
  filter(COVID == 1) %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 209720) %>%
  ungroup() %>%
  left_join(pea_grupo_2020, by = c("grupo", "hierarquia")) %>%
  mutate(obitos_covid_cada_100_grupo_2020 = (obitos_covid / obitos_grupo) * 100) %>%
  filter(obitos_grupo > 50)

# 5.2 - Síntese para 2021
sint_covid_pea_grupo_2021 <- pea_sim %>%
  filter(ANO == 2021) %>%
  filter(COVID == 1) %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 420345) %>%
  ungroup() %>%
  left_join(pea_grupo_2021, by = c("grupo", "hierarquia")) %>%
  mutate(obitos_covid_cada_100_grupo_2021 = (obitos_covid / obitos_grupo) * 100) %>%
  filter(obitos_grupo > 50)

# 5.3 - Comparando crescimento mortalidade covid entre anos:
sint_covid_pea_grupo_comparacao <- sint_covid_pea_grupo_2020 %>%
  bind_cols(sint_covid_pea_grupo_2021) %>%
  mutate(aumento_percentual = (obitos_covid_cada_100_grupo_2021 - obitos_covid_cada_100_grupo_2020) / obitos_covid_cada_100_grupo_2020) %>%

  order(aumento_percentual)

# 5.4 - Salvando:
setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\outputs")
write.xlsx(sint_covid_pea_grupo_comparacao, "sint_covid_pea_grupo_comparacao.xlsx")

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##| 4. Gráfico de dispersão:             |##|
# |##|    sint_covid_pea, cbo_4_agreg       |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# 1. Gráfico de dispersão: n° Óbitos covid na categoria vs óbitos na categoria
top_10_covid_pea <- sint_covid_pea %>%
  top_n(10, obitos_covid) %>%
  arrange(desc(obitos_covid))

top_10_covid_pea %>%
  ggplot(aes(obitos_covid, obitos_cbo_4), label = cbo_4_agreg) +
  geom_point(aes(colour = cbo_4_agreg), shape = 1) +
  geom_label_repel(aes(label = cbo_4_agreg, fill = factor(cbo_4_agreg)),
                   colour = "white", fontface = "bold") +
  scale_x_continuous(breaks = seq(0, 3800, 200)) +
  labs(caption = "Fonte: SIM/DATASUS, 2020",
       title = "Óbitos covid na categoria vs óbitos na categoria",
       x = "",
       y = "") +
  theme(plot.title = element_text(size = 14, face = "bold"),
        legend.position = "none")

# 2. Gráfico de dispersão cbo_4_agreg: % Óbitos covid na categoria vs óbitos na categoria
top_10_covid_pea_cada_100 <- sint_covid_pea %>%
  top_n(10, obitos_covid_cada_100_cbo_4_agreg) %>%
  arrange(desc(obitos_covid_cada_100_cbo_4_agreg))

top_10_covid_pea_cada_100 %>%
  ggplot(aes(obitos_covid_cada_100_cbo_4_agreg, obitos_covid), label = cbo_4_agreg) +
  geom_point(aes(colour = factor(cbo_4_agreg), size = obitos_cbo_4)) +
  # geom_jitter(aes(colour = factor(cbo_4), size = obitos_cbo_4)) +
  # ggrepel::geom_text_repel(aes(label = cbo_4, size = 500),
  #                          position = position_stack(vjust = 1.05)) +
  geom_label_repel(aes(label = cbo_4_agreg),
                   colour = "black", fontface = "bold") +
  scale_x_continuous(breaks = seq(10, 50, 5)) +
  labs(caption = "Fonte: SIM/DATASUS, 2020",
       x = "% de óbitos covid na categoria",
       y = "Óbitos covid na categoria") +
  theme(plot.title = element_text(size=10), legend.position = "none")

# 3. Gráfico de dispersão grupo: % Óbitos covid na categoria vs óbitos na categoria
sint_covid_pea_grupo %>%
  filter(!is.na(grupo)) %>%
  mutate(classif = case_when(obitos_covid_cada_100_grupo < 20 ~ "Menos que 10%",
                             obitos_covid_cada_100_grupo >= 20 &
                               obitos_covid_cada_100_grupo < 30 ~ "Entre 10% e 20%",
                             obitos_covid_cada_100_grupo >= 30 ~ "Mais que 20%")) %>%
  ggplot(aes(obitos_covid, obitos_covid_cada_100_grupo),
         size = obitos_grupo, label = grupo) +
  geom_point(aes(colour = factor(classif), size = obitos_grupo), alpha = .5) +
  # geom_jitter(aes(colour = factor(grupo), size = obitos_grupo), alpha = .5) +
  # geom_text_repel(aes(label = grupo), size = 3) +
  #geom_text(aes(label = grupo), size = 3) +
  scale_size(range = c(3, 45), name="Total de óbitos") +
  geom_label_repel(aes(label = paste0(grupo, " ~ ", round(obitos_covid_cada_100_grupo), "%")), size = 3,
                   family = "ubuntu", fontface = "bold") +
  # scale_x_continuous(breaks = seq(10, 50, 5)) +
  # scale_y_continuous(limits = c(-.05, .45), labels = percent) +
  scale_y_continuous(limits = c(-2, 60), labels = function(x) paste0(x, "%")) + # x*100
  labs(caption = "Fonte: SIM/DATASUS, 2020-2021",
       y = "% óbitos Covid-19 no grupo ocupacional",
       x = "N° óbitos Covid-19 no grupo ocupacional") +
  theme(plot.title = element_text(size=10), legend.position = "none")


# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|Perfil ocupacional por grupo específico##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

# Covid: perfil ocupacional e marcadores sociais da diferença

## Idade
## Dispersão + Regressão Linear
sint_covid_pea %>%
  ggplot(aes(idade_media_cbo_4, obitos_covid_cada_100_cbo_4,
             size = obitos_cbo_4)) +
  geom_point(alpha = .3) +
  geom_smooth(method = lm) +
  ggpmisc::stat_poly_eq(formula = y ~ x,
                        aes(label = paste(..eq.label..,
                                          ..rr.label..,
                                          sep = "~~~")),
                        parse = TRUE) +
  labs(x = "Idade média dos óbitos na categoria",
       y = "% óbitos covid",
       caption = "* Ocupações com pelo menos 50 óbitos") +
  theme(plot.title = element_text(size=10), legend.position = "none")


glimpse(sint_covid_pea)

#
sint_covid_pea %>%
  ggplot(aes(idade_media_cbo_4, obitos_covid)) +
  geom_point(alpha = .3) +
  geom_smooth(method = lm) +
  ggpmisc::stat_poly_eq(formula = y ~ x,
                        aes(label = paste(..eq.label.., ..rr.label..,
                                          sep = "~~~")),
                        parse = TRUE) +
  labs(x = "Idade média dos óbitos na categoria",
       y = "Óbitos covid") +
  theme(plot.title = element_text(size=10), legend.position = "none")

## Raça/cor
sint_cor <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  filter(!is.na(RACACOR)) %>%
  group_by(id_cbo_4, cbo_4, RACACOR) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  ungroup() %>%
  left_join(pea_cbo_4_cor, by = c("id_cbo_4", "cbo_4", "RACACOR")) %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4_cor = obitos_covid / obitos_cbo_4_cor * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4_cor > 50)

## NA's em raça/cor
pea_sim_2020 %>%
  filter(COVID == 1) %>%
  filter(is.na(RACACOR)) %>%
  count() ### 739

## Densidade (escala logarítimica)
sint_cor %>%
  filter(RACACOR != "Indigena") %>%
  ggplot(aes(log(obitos_covid_cada_100_cbo_4_cor), fill = RACACOR)) +
  geom_density(alpha = .3) +
  theme_bw() +
  theme(legend.position = "bottom", legend.title = element_blank()) +
  labs(x = "Óbitos covid a cada 100 da mesma cor na categoria (log)",
       caption = "* Ocupações com pelo menos 50 óbitos")

## Histogramas de densidade
sint_cor %>%
  filter(RACACOR != "Indigena") %>%
  ggplot(aes(log(obitos_covid_cada_100_cbo_4_cor))) +
  geom_histogram(aes(y = ..density..), bins = 30, alpha = .7) +
  geom_density(aes(y = ..density..), alpha = .3) +
  theme_bw() +
  facet_wrap(~ RACACOR) +
  labs(x = "Óbitos covid a cada 100 da mesma cor na categoria",
       caption = "* Ocupações com pelo menos 50 óbitos")

## Gênero
sint_sexo <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  group_by(id_cbo_4, cbo_4, SEXO) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  ungroup() %>%
  left_join(pea_cbo_4_sexo, by = c("id_cbo_4", "cbo_4", "SEXO")) %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4_sexo = obitos_covid / obitos_cbo_4_sexo * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4_sexo > 50)

##
sint_sexo %>%
  ggplot(aes(obitos_covid_cada_100_cbo_4_sexo, fill = SEXO)) +
  geom_boxplot() +
  theme_bw() +
  theme(legend.position = "bottom", legend.title = element_blank()) +
  labs(x = "Óbitos covid a cada 100 do mesmo sexo na categoria",
       caption = "* Ocupações com pelo menos 50 óbitos")

# (6) Síntese: óbitos pea e covid por cbo_4, sexo e cor
sint_sexo_cor <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  filter(!is.na(RACACOR)) %>%
  group_by(id_cbo_4, cbo_4, SEXO, RACACOR) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  ungroup() %>%
  left_join(pea_cbo_4_sexo_cor,
            by = c("id_cbo_4", "cbo_4", "SEXO", "RACACOR")) %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4_sexo_cor = obitos_covid / obitos_cbo_4_sexo_cor * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4_sexo_cor > 50)

## Boxplots
sint_sexo_cor %>%
  filter(RACACOR != "Indigena") %>%
  ggplot(aes(obitos_covid_cada_100_cbo_4_sexo_cor)) +
  geom_boxplot() +
  facet_grid(SEXO ~ RACACOR) +
  theme_bw() +
  labs(x = "Óbitos covid a cada 100 da mesma cor e do mesmo sexo na categoria",
       caption = "* Ocupações com pelo menos 50 óbitos")

## Histogramas de densidade
sint_sexo_cor %>%
  filter(RACACOR != "Indigena") %>%
  # ggplot(aes(log(obitos_covid_cada_100_cbo_4_sexo_cor), fill = RACACOR)) +
  ggplot(aes(obitos_covid_cada_100_cbo_4_sexo_cor, fill = RACACOR)) +
  geom_density(alpha = .3) +
  theme_bw() +
  facet_wrap(~ SEXO) +
  theme(legend.position = "bottom", legend.title = element_blank()) +
  labs(x = "Óbitos covid a cada 100 da mesma cor e do mesmo sexo na categoria",
       # x = "Óbitos covid a cada 100 da mesma cor e do mesmo sexo na categoria (log)",
       caption = "* Ocupações com pelo menos 50 óbitos")

# (7) Covid: dinâmica regional e urbana

## Síntese: óbitos pea e covid por centralidade urbana
sint_rm <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  filter(!is.na(metro)) %>%
  group_by(cbo_4, metro) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  left_join(pea_cbo_4, by = "cbo_4") %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4 = obitos_covid / obitos_cbo_4 * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4 > 50)

## Densidades
sint_rm %>%
  ggplot(aes(obitos_covid_cada_100_cbo_4, fill = metro)) +
  geom_density(alpha = .3) +
  theme(legend.position = "bottom", legend.title = element_blank())


##
sint_regioes <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  filter(!is.na(name_region)) %>%
  group_by(cbo_4, name_region) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  left_join(pea_cbo_4, by = "cbo_4") %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4 = obitos_covid / obitos_cbo_4 * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4 > 50)

##
sint_regioes %>%
  ggplot(aes(obitos_covid_cada_100_cbo_4)) +
  geom_histogram(aes(y = ..density..), alpha = .7) +
  geom_density(alpha = .3) +
  facet_wrap(~ name_region)

# (8) Covid PEA: escolaridade

##
sint_esc <- pea_sim_2020 %>%
  filter(COVID == 1) %>%
  group_by(cbo_4, ESC) %>%
  summarize(obitos_covid = n_distinct(id_obito)) %>%
  left_join(pea_cbo_4, by = "cbo_4") %>%
  rowwise() %>%
  mutate(obitos_covid_cada_100_cbo_4 = obitos_covid / obitos_cbo_4 * 100) %>%
  ungroup() %>%
  filter(!is.na(cbo_4) & obitos_cbo_4 > 50)

## Densidades
sint_esc %>%
  ggplot(aes(log(obitos_covid_cada_100_cbo_4))) +
  geom_histogram(aes(y = ..density..), alpha = .7) +
  geom_density(alpha = .3) +
  facet_wrap(~ factor(ESC,
                      levels = c("NA ou ignorado", "Nenhuma",
                                 "1 a 3 anos de estudo",
                                 "4 a 7 anos de estudo",
                                 "8 a 11 anos de estudo",
                                 "12 anos ou mais"))) +
  labs(caption = "* Ocupações com pelo menos 50 óbitos")

# Aplicando a AED a dados recodificados
## Incorporando a recodificação proposta por análise quali do especialista

##
#drive_auth("xxx")
api_cbo_familia_agregada <- drive_download(as_id("1pRDNqqY30lproDTn3rqSRUqrw7ZFyK9a"),
                                           path = tempfile(fileext = ".xlsx"),
                                           overwrite = TRUE)

## Importando
cbo_familia_ajustada <- read_excel(api_cbo_familia_agregada$local_path) %>%
  transmute(id_cbo_4,
            id_cbo_4_agreg,
            cbo_4_agreg,
            grupo, hierarquia)

##
pea_sim_2020_ajust <- pea_sim_2020 %>%
  left_join(cbo_familia_ajustada, by = "id_cbo_4")

###
filter(pea_sim_2020_ajust, is.na(hierarquia)) %>%
  count() # 9259 óbitos sem informação ocupacional

###
list(n_ocup_pea = pea_sim_2020_ajust$id_cbo_4,
     n_ocup_ajust = cbo_familia_ajustada$id_cbo_4,
     n_ocup_pea_ajust = pea_sim_2020_ajust %>% filter(COVID == 1)
     %>% select(id_cbo_4)) %>%
  map_dfr(., n_distinct) #494 famílias de ocupação ajustadas, faltando 291/380

###
pea_cbo_4_agreg <- pea_sim_2020_ajust %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg) %>%
  summarize(obitos_cbo_4_agreg = n_distinct(id_obito)) %>%
  arrange(desc(obitos_cbo_4_agreg))

### Filtradas as ocupações com menos do que 50 óbitos registrados no SIM 2020
sint_covid_pea_ajust <- pea_sim_2020_ajust %>%
  filter(COVID == 1) %>%
  group_by(id_cbo_4, cbo_4, id_cbo_4_agreg, cbo_4_agreg, grupo, hierarquia) %>%
  summarize(obitos_covid = n_distinct(id_obito),
            prop_obitos_covid = obitos_covid / 206646) %>%
  ungroup() %>%
  left_join(pea_cbo_4, by = c("id_cbo_4", "cbo_4")) %>%
  mutate(obitos_covid_cada_100_cbo_4 = obitos_covid / obitos_cbo_4 * 100) %>%
  filter(obitos_cbo_4 > 50)  %>%
  group_by(id_cbo_4_agreg, cbo_4_agreg, grupo, hierarquia) %>%
  summarize(obitos_covid_agreg = sum(obitos_covid),
            prop_obitos_covid_agreg = obitos_covid_agreg / 206646) %>%
  ungroup() %>%
  left_join(pea_cbo_4_agreg, by = c("id_cbo_4_agreg", "cbo_4_agreg")) %>%
  mutate(obitos_covid_cada_100_cbo_4_agreg = obitos_covid_agreg/ obitos_cbo_4_agreg * 100,
         cbo_4_agreg = case_when(is.na(cbo_4_agreg) ~ "Não classificado",
                                 TRUE ~ cbo_4_agreg))

###
sint_covid_pea_grupos <- pea_sim_2020_ajust %>%
  group_by(grupo, hierarquia) %>%
  summarize(obitos_covid_grupo = sum(COVID == 1),
            prop_obitos_covid = obitos_covid_grupo / 206646,
            obitos_grupo = n_distinct(id_obito)) %>%
  ungroup() %>%
  mutate(obitos_covid_cada_100_grupo = obitos_covid_grupo / obitos_grupo,
         grupo = case_when(hierarquia == 5 ~ "Adm's, Contadores e afins",
                           hierarquia == 7 ~ "Comunicação",
                           hierarquia == 4 ~ "Ensino Superior",
                           hierarquia == 18 ~ "Limpeza Urbana",
                           hierarquia == 16 ~ "Indústria de Transformação",
                           is.na(hierarquia) ~ "Outros",
                           TRUE ~ grupo),
         classif = case_when(obitos_covid_cada_100_grupo < .1 ~ "Menos que 10%",
                             obitos_covid_cada_100_grupo >= .1 &
                               obitos_covid_cada_100_grupo < .2 ~ "Entre 10% e 20%",
                             obitos_covid_cada_100_grupo >= .2 ~ "Mais que 20%"))

###
sint_covid_pea_grupos %>%
  ggplot(aes(obitos_covid_grupo, obitos_covid_cada_100_grupo),
         size = obitos_grupo, label = grupo) +
  geom_point(aes(colour = factor(classif), size = obitos_grupo), alpha = .5) +
  # geom_jitter(aes(colour = factor(grupo), size = obitos_grupo), alpha = .5) +
  # geom_text_repel(aes(label = grupo), size = 3) +
  #geom_text(aes(label = grupo), size = 3) +
  scale_size(range = c(3, 45), name="Total de óbitos") +
  geom_label_repel(aes(label = paste0(grupo, " ~ ", round(obitos_covid_cada_100_grupo*100), "%")), size = 3,
                   family = "ubuntu", fontface = "bold") +
  # scale_x_continuous(breaks = seq(10, 50, 5)) +
  # scale_y_continuous(limits = c(-.05, .45), labels = percent) +
  scale_y_continuous(limits = c(-.01, .45), labels = function(x) paste0(x*100, "%")) +
  labs(caption = "Fonte: SIM/DATASUS, 2020",
       y = "% óbitos Covid-19 no grupo ocupacional",
       x = "Óbitos Covid-19 no grupo ocupacional") +
  theme(plot.title = element_text(size=10), legend.position = "none")


# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    2. Gráfico: mensal mortes covid   |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

pea_sim_2 <- pea_sim %>%
  mutate(mes = case_when(DATAOBITO >= "2020-01-01" & DATAOBITO < "2020-02-01" ~ "01 - Jan/2020",
                         DATAOBITO >= "2020-02-01" & DATAOBITO < "2020-03-01" ~ "02 - Fev/2020",
                         DATAOBITO >= "2020-03-01" & DATAOBITO < "2020-04-01" ~ "03 - Mar/2020",
                         DATAOBITO >= "2020-04-01" & DATAOBITO < "2020-05-01" ~ "04 - Abr/2020",
                         DATAOBITO >= "2020-05-01" & DATAOBITO < "2020-06-01" ~ "05 - Mai/2020",
                         DATAOBITO >= "2020-06-01" & DATAOBITO < "2020-07-01" ~ "06 - Jun/2020",
                         DATAOBITO >= "2020-07-01" & DATAOBITO < "2020-08-01" ~ "07 - Jul/2020",
                         DATAOBITO >= "2020-08-01" & DATAOBITO < "2020-09-01" ~ "08 - Ago/2020",
                         DATAOBITO >= "2020-09-01" & DATAOBITO < "2020-10-01" ~ "09 - Set/2020",
                         DATAOBITO >= "2020-10-01" & DATAOBITO < "2020-11-01" ~ "10 - Out/2020",
                         DATAOBITO >= "2020-11-01" & DATAOBITO < "2020-12-01" ~ "11 - Nov/2020",
                         DATAOBITO >= "2020-12-01" & DATAOBITO < "2021-01-01" ~ "12 - Dez/2020",
                         DATAOBITO >= "2021-01-01" & DATAOBITO < "2021-02-01" ~ "13 - Jan/2021",
                         DATAOBITO >= "2021-02-01" & DATAOBITO < "2021-03-01" ~ "14 - Fev/2021",
                         DATAOBITO >= "2021-03-01" & DATAOBITO < "2021-04-01" ~ "15 - Mar/2021",
                         DATAOBITO >= "2021-04-01" & DATAOBITO < "2021-05-01" ~ "16 - Abr/2021",
                         DATAOBITO >= "2021-05-01" & DATAOBITO < "2021-06-01" ~ "17 - Mai/2021",
                         DATAOBITO >= "2021-06-01" & DATAOBITO < "2021-07-01" ~ "18 - Jun/2021",
                         DATAOBITO >= "2021-07-01" & DATAOBITO < "2021-08-01" ~ "19 - Jul/2021",
                         DATAOBITO >= "2021-08-01" & DATAOBITO < "2021-09-01" ~ "20 - Ago/2021",
                         DATAOBITO >= "2021-09-01" & DATAOBITO < "2021-10-01" ~ "21 - Set/2021",
                         DATAOBITO >= "2021-10-01" & DATAOBITO < "2021-11-01" ~ "22 - Out/2021",
                         DATAOBITO >= "2021-11-01" & DATAOBITO < "2021-12-01" ~ "23 - Nov/2021",
                         DATAOBITO >= "2021-12-01" & DATAOBITO <= "2021-12-31" ~ "24 - Dez/2021"),
         RACA_SEXO = case_when(SEXO == "Homem" & RACACOR == "Preto ou pardo" ~ "Preto ou pardo - Homem",
                               SEXO == "Homem" & RACACOR == "Branco ou Amarelo" ~ "Branco ou Amarelo - Homem",
                               SEXO == "Mulher" & RACACOR == "Preto ou pardo" ~ "Preto ou pardo - Mulher",
                               SEXO == "Mulher" & RACACOR == "Branco ou Amarelo" ~ "Branco ou Amarelo - Mulher")) %>%
  filter(!is.na(SEXO) & RACACOR != "Indigena")

pea_sim_3 <- pea_sim_2 %>%
  #group_by(mes, RACA_SEXO) %>%
  group_by(mes, RACACOR, SEXO) %>%
  summarise(proporcao = mean(COVID),
            n_mortes = n(),
            n_mortes_covid = sum(COVID==1),
            proporcao_2 = n_mortes_covid/n_mortes)

# Coferindo totais e proporções:
pea_sim_3 %>%
  summarise(n_mortes = sum(n_mortes),
            n_mortes_covid = sum(n_mortes_covid)) %>%
  summarise(n_mortes = sum(n_mortes),
            n_mortes_covid = sum(n_mortes_covid))

pea_sim_2 %>%
  filter(COVID==1) %>%
  summarise(n = n())

# Construindo gráfico de mortes por mês:
pea_sim_3 %>%
  ggplot(aes(mes, proporcao*100)) +
  geom_bar(stat = "identity", position = "dodge", colour="black", fill="#DD8888", width=.8) +
  facet_grid(vars(SEXO), vars(RACACOR)) +
  #facet_wrap(~RACA_SEXO, ncol=1) +
  #geom_text(aes(label = round(propo, 2)), position = position_dodge(width = 0.9), vjust = -1) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 80, vjust = 0.5, hjust=0.5),
        axis.title.x=element_blank(),
        axis.title.y=element_text(size = 13.5, face = "bold"),
        #axis.ticks.x=element_blank(),
        strip.background = element_rect(colour="black", fill="azure2",
                                        size=0.5, linetype="solid"),
        strip.text.x = element_text(size=12, color="black",
                                    face="bold"),
        strip.text.y = element_text(size=12, color="black",
                                    face="bold")) +
  ylab("% de mortes por covid")

# Salvando tabela para fazer gráfico mensal:
setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\outputs")

write.xlsx(pea_sim_3, "pea_sim_agrupado por mes e sexoraca_filtro de indigenas e missing em sexo.xlsx")

# .--------------------------------------------.
# |############################################|
# |##.--------------------------------------.##|
# |##|    2. Gráfico: mensal mortes covid   |##|
# |##°--------------------------------------°##|
# |############################################|
# '--------------------------------------------°

setwd("C:\\Users\\alexandre pichilinga\\Documents\\1_afrodata\\covid\\data")
pea_sim_rogerio <- read.xlsx("pea_sim_agrupado por mes e sexoraca_filtro de indigenas e missing em sexo_revROGERIOBarbosa.xlsx", sheet = 3)

pea_sim_rogerio %>%
  rename(hb_mn = `HB-MN`) %>%
  ggplot(aes(y=hb_mn, x=`mês`)) +
  geom_bar(position="stack", stat="identity", colour="black", fill="#DD8888", width=.8) +
  theme_minimal() +
  labs(title = "% de chance de morrer por covid-19 de Homens Brancos \nem relação a Mulheres Pretas") +
  ylab("% de chance de morrer por covid") +
  theme(axis.text.x = element_text(angle = 80, vjust = 0.5, hjust=0.5),
        axis.text.y = element_text(vjust = 0.5, hjust=0.5, size = 11),
                     axis.title.x=element_blank(),
        axis.title.y=element_text(size = 14, face = "bold", vjust = 2),
        plot.title = element_text(size = 16))

pea_sim_rogerio %>%
  rename(hn_mn = `HN-MN`) %>%
  ggplot(aes(y=hn_mn, x=`mês`)) +
  geom_bar(position="stack", stat="identity", colour="black", fill="#DD8888", width=.8) +
  theme_minimal() +
  labs(title = "% de chance de morrer por covid-19 de Homens Pretos \nem relação a Mulheres Pretas") +
  ylab("% de chance de morrer por covid") +
  theme(axis.text.x = element_text(angle = 80, vjust = 0.5, hjust=0.5),
        axis.text.y = element_text(vjust = 0.5, hjust=0.5, size = 11),
        axis.title.x=element_blank(),
        axis.title.y=element_text(size = 14, face = "bold", vjust = 2),
        plot.title = element_text(size = 16))

# mulheres brancas
pea_sim_rogerio %>%
  rename(mb_mn = `MB-MN`) %>%
  ggplot(aes(y=mb_mn, x=`mês`)) +
  geom_bar(position="stack", stat="identity", colour="black", fill="#DD8888", width=.8) +
  theme_minimal() +
  labs(title = "% de chance de morrer por covid-19 de Mulheres Brancas \nem relação a Mulheres Pretas") +
  ylab("% de chance de morrer por covid") +
  theme(axis.text.x = element_text(angle = 80, vjust = 0.5, hjust=0.5),
        axis.text.y = element_text(vjust = 0.5, hjust=0.5, size = 11),
        axis.title.x=element_blank(),
        axis.title.y=element_text(size = 14, face = "bold", vjust = 2),
        plot.title = element_text(size = 16))

#                                      ~~~~~ Fim ~~~~~
