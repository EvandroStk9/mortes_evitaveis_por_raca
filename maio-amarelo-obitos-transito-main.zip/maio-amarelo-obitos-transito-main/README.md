# Maio Amarelo - Mortes no Trânsito no Brasil

Este repositório contém análises sobre óbitos por acidentes de trânsito (CID-10 V01–V89) no Brasil entre 2000 e 2024, usando dados do DATASUS e do IBGE.

![preview](outputs/figuras/11_tipo_vitima_pct.png)

## 📁 Estrutura do Projeto

- `dados`: Dados brutos importados e dados processados já tratados.
- `scripts`: Importação, tratamento e criação da visualização das análises.
- `outputs`: Gráficos finais em PNG.

## 🛠️ Tecnologias Utilizadas

- **Linguagem**: R
- **Importação**: sidrar, microdatasus
- **Tratamento**: dplyr
- **Visualização**: ggplot2, geobr, sysfonts, showtext, ggtext

## 📊 Fonte dos Dados

Os dados foram importados diretamente do DATASUS (óbitos e classificações) e do Sidra (estimativas populacionais)

## 📓 Notas metodológicas

- **Mortes**: óbitos com causa básica CID-10 entre **V01 e V89** - acidentes
  de **transporte terrestre** (pedestres, ciclistas, motociclistas, ocupantes
  de auto/caminhonete/caminhão/ônibus, trens, veículos especiais e não
  especificados). Exclui V90–V97 (aquático e aéreo) e V98–V99 (não
  classificados). 
- **Local**: município de **ocorrência** do óbito (não residência).

## 👤 Autor

Artur Vidaurre de Almeida

